# Fragments

## Fragment 1
![a](https://user-images.githubusercontent.com/41099217/111143574-08994c00-85ae-11eb-8130-1fd09f7b9616.png)

## Fragment 2
![b](https://user-images.githubusercontent.com/41099217/111143639-236bc080-85ae-11eb-8b0d-2dc116feddf2.png)

## checkBox radio button
![c](https://user-images.githubusercontent.com/41099217/111143668-2ebeec00-85ae-11eb-9f76-3f8cc3aeca8f.png)

## Second Activity
![d](https://user-images.githubusercontent.com/41099217/111143728-40a08f00-85ae-11eb-8696-419958b5d64f.png)

## GIF Overview of Fragment App
![fragment](https://user-images.githubusercontent.com/41099217/111143841-64fc6b80-85ae-11eb-8f78-fb95c096bf54.gif)



